package org.shub.sdet.wipro;

import java.util.ArrayList;

public class GetResponse {
	String status;
	ArrayList<Emp> data;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public ArrayList<Emp> getData() {
		return data;
	}
	public void setData(ArrayList<Emp> data) {
		this.data = data;
	}
	
	

}
