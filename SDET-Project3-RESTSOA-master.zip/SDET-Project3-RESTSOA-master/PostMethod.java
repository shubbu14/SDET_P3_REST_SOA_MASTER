package org.shub.sdet.wipro;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import static org.hamcrest.Matchers.*;

public class PostMethod {
	public static Map<String,String> map=new HashMap<String,String>();
	@BeforeClass
	public void setup() {
		RestAssured.baseURI = "http://jsonplaceholder.typicode.com";
		RestAssured.basePath = "/posts/";
	}
	@BeforeTest
	public void postdata() {
		map.put("userId", "2");
		map.put("id", "19");
		map.put("title", "this is projectdebug.com");
		map.put("body", "this is REST-Assured Tutorial");
		
	}

	@Test
	public void testPOST() {
		given().contentType("application/json").body(map).when().post().then().statusCode(201).and().body("title",
				equalTo("this is projectdebug.com"));
	}
}