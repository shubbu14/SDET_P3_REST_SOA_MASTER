package org.shub.sdet.wipro;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Headers;

import static io.restassured.RestAssured.*;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import static org.hamcrest.Matchers.*;

public class DELETEMethod {
	@BeforeClass
	public void setup(){
		
		RestAssured.baseURI = "http://jsonplaceholder.typicode.com";
		RestAssured.basePath = "/posts/";
	}

	@Test
	public void testDelete(){
		Headers headers=given()
		.when()
		.delete("/100").thenReturn().getHeaders();
		for(Header h:headers)
		System.out.println(h.getName()+h.getValue());
		
		int stc=given().delete("/100").thenReturn().getStatusCode();
		System.out.println(stc);
		//.then()
		//.header("Expires", equalTo("-1"));		
	}
}