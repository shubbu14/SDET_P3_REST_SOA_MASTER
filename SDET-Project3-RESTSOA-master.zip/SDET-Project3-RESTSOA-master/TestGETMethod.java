package org.shub.sdet.wipro;


import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import java.util.Iterator;

public class TestGETMethod {
	@BeforeClass
	public void setup() {
		RestAssured.baseURI = "http://dummy.restapiexample.com/api/v1";
		RestAssured.basePath = "/employees";
	}

	@Test(priority = 1)
	public void testStatusCode() {

		// Response httpResponse = httpRequest.request(Method.GET, "/employees");
		// System.out.println(httpResponse.asString());
		// System.out.println("Body=" + httpResponse.getBody().asString());
		
		// Headers headers = httpResponse.getHeaders(); for (Header header : headers) {
		 // System.out.println(header.getName() + " = " + header.getValue()); }
		 
		// Response
		given().log().all().get().then().assertThat().statusCode(200);

	}

	@Test(priority = 2)
	public void testBody() {
	String s = given().get().getBody().asString();
	System.out.println(s);

		
		 GetResponse list = given().log().all().get().getBody().as(GetResponse.class);
		 
		 for (Emp e : list.getData()) 
            System.out.println(e);
		 
		 
		
		// get().jsonPath().getJsonObject(path).assertThat().b;
	}

	@Test(priority = 3)
	public void testHeader() {
	System.out.println(given().get().header("Content-type"));
	given().get().then().header("Content-Type", "application/json;charset=utf-8");
		
	}
}